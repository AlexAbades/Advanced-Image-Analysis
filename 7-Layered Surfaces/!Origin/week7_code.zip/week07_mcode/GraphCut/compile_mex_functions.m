% compiling mex functions

mex  GraphCutMex.cpp MaxFlow.cpp graph.cpp 
